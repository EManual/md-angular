AngularjsTutorial_cn
====================

AngularJS入门教程——[AngularJS中文社区](http://angularjs.cn/)提供

**AngularJS中文社区**是一个专业的AngularJS中文开源技术社区，致力于AngularJS的技术学习、交流和研究。

我们非常欢迎更多对AngularJS感兴趣的朋友[加入](http://angularjs.cn/register)！

-----

1、 **angularjs**

**新浪微博：**[@ZENSH严清][1] **任务：**管理AngularJS中文社区，初步校核翻译文档；

2、 **rainer_H**

**新浪微博：**[@l4future][2] **任务：**翻译“Dveloper Guide”部分；

3、**furtherLee**

**新浪微博：**[@速冻沙漠][3] **任务：**翻译“Angular Tutorial”部分。


 [1]: http://weibo.com/zensh
 [2]: http://weibo.com/u/1856964593
 [3]: http://weibo.com/u/1901891651

### AngularJS入门教程目录

1. [快速开始](http://angularjs.cn/A002 "AngularJS快速开始")
2. [导言和准备](http://angularjs.cn/A00g "AngularJS入门教程：导言和准备")
3. [引导程序](http://angularjs.cn/A003 "AngularJS入门教程00：引导程序")
4. [静态模板](http://angularjs.cn/A004 "AngularJS入门教程01：静态模板")
5. [AngularJS模板](http://angularjs.cn/A005 "AngularJS入门教程02：AngularJS模板")
6. [迭代器过滤](http://angularjs.cn/A006 "AngularJS入门教程03：迭代器")
7. [双向绑定](http://angularjs.cn/A007 "AngularJS入门教程04：双向绑定")
8. [XHR和依赖注入](http://angularjs.cn/A008 "AngularJS入门教程05：XHR和依赖注入")
9. [链接与图片模板](http://angularjs.cn/A009 "AngularJS入门教程06：链接与图片模板")
10. [路由与多视图](http://angularjs.cn/A00a "AngularJS入门教程07：路由与多视图")
11. [更多模板](http://angularjs.cn/A00b "AngularJS入门教程08：更多模板")
12. [过滤器](http://angularjs.cn/A00c "AngularJS入门教程09：过滤器")
13. [事件处理器](http://angularjs.cn/A00d "AngularJS入门教程10：事件处理器")
14. [REST和定制服务](http://angularjs.cn/A00e "AngularJS入门教程11：REST和定制服务")
15. [完结篇](http://angularjs.cn/A00f "AngularJS入门教程12：完结篇")
